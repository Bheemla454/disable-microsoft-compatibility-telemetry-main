![](https://i.imgur.com/OE4EqsV.png 'Microsoft Compatibility Telemetry')

Script to disable Microsoft Compatibility Telemetry that collects data about your computer's performance and usage
